﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Citations.Models
{
    public class vmarticlerisk
    {
        public int keywordid { get; set; }

        public string keywordname { get; set; }

        public bool assigned { get; set; }
    }
}
